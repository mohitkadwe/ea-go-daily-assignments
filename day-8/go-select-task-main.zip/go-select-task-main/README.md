# go-select-task

This repo is for learning purpose. It consist go files with broken code.
Please check them and fix them using go `select`.

